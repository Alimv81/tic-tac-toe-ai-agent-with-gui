from utils import *


run_ask_page()
run_game_page()